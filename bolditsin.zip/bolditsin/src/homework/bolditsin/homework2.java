package homework.bolditsin;
import java.util.Arrays;

public class homework2 {

    public static void main(String[] args)
    {
        swap();
        plusthree();
        multiplyx2();
        diag();
    }
    static void swap()
    {
        int[] arr = {0, 0, 1, 0, 1, 0};
        for(int i = 0; i < arr.length; i++)
        {
            if (arr[i]==0)
            {
                arr[i]=1;
            }
            else
            {
                arr[i]=0;
            }
        }
        System.out.println(Arrays.toString(arr));

    }

    static void plusthree()
    {
        int[] arr2 = new int[8];
        int a=0;
        for(int i = 0; i < arr2.length; i++, a= a+3)
        {
            arr2[i]=a;
        }
        System.out.println(Arrays.toString(arr2));
    }

    static void multiplyx2()
    {
        int[] arr3 = {1, 5, 3, 2, 11, 4, 5, 2, 4, 8, 9, 1};
        for(int i=0; i < arr3.length; i++)
        {
            if (arr3[i]<6)
            {
                arr3[i]=arr3[i]*2;
            }
        }
        System.out.println(Arrays.toString(arr3));
    }

    static void diag()
    {
        int a=5;
        int[][] arr4 =new int[a][a];
        for(int i=0; i< a; i++)
        {
            for(int j=0; j<a; j++)
            {
                if((i==j) || (i==a-1-j))
                {
                    arr4[i][j] = 1;
                }
                else arr4[i][j] = 0;
            }
        }
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                System.out.print(arr4[i][j]+" ");
            }
            System.out.println();
        }
    }
}
